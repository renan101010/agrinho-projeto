let carroX = 0;

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(255);
  
  // Desenhar o campo à esquerda
  fill(34, 139, 34); // verde para o campo
  rect(50, 150, 200, 200);
  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);
  fill(255);
  text("Campo", 150, 350);
  fill(0);
  rect(580, height/2 - 80, 50, 250); // prédio
  rect(640, height/2 - 80, 50, 250);
  rect(700, height/2 - 80, 50, 250);  
  
  // Desenha o carro
  fill(255, 0, 0);
  rect(carroX, height/2 - 20, 100, 40); // corpo do carro
  
  fill(0);
  ellipse(carroX + 20, height/2 + 20, 20, 20); // roda esquerda
  ellipse(carroX + 80, height/2 + 20, 20, 20); // roda direita
  
  // Move o carro
  carroX += 2;
  
  // Reinicia a posição quando sair da tela
  if (carroX > width) {
    carroX = -100;
  }

  
  
  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);
  fill(255);
  text("Cidade", 650, 350);
  fill(150);
  
  // Conectar os dois com uma linha
  stroke(90);
  strokeWeight(5);
  line(250, 250, 550, 250);
  
  // Opcional: adicionar elementos que representam a conexão
  fill(0);
  noStroke();
  textSize(14);
  text("Conexão entre campo e cidade", 400, 50);
  fill(255, 215, 0);
  ellipse(200, 250, 100, 20); // símbolo de conexao 

 }
